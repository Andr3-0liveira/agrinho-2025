let personagemX; // Posição X do personagem
let fitaCortada = false; // Estado da fita
let fogos = []; // Array para armazenar os fogos de artifício

function setup() {
  createCanvas(800, 400); // Cria uma tela de 800x400 pixels
  personagemX = 50; // Posição inicial do personagem
}

function draw() {
  // Desenha o campo (fundo verde)
  background(144, 238, 144); // Verde claro

  // Desenha a estrada (marrom)
  fill(139, 69, 19);
  noStroke(); // Sem borda para a estrada
  rect(0, height / 2 - 20, width, 40); // Uma faixa no meio da tela

  // Desenha cercas e árvores
  desenharElementosCenario();

  // Desenha a cidade (prédios no final)
  desenharCidade();

  // Desenha a fita de chegada se não foi cortada
  if (!fitaCortada) {
    desenharFita();
  }

  // Desenha o personagem
  desenharPersonagem();

  // Lógica de movimento do personagem
  if (keyIsDown(RIGHT_ARROW)) {
    personagemX += 2; // Move para a direita
  }
  if (keyIsDown(LEFT_ARROW)) {
    personagemX -= 2; // Move para a esquerda
    personagemX = max(50, personagemX); // Garante que não vá muito para trás
  }

  // Limita o personagem para não passar da fita antes de cortar
  if (!fitaCortada && personagemX >= width - 180) {
    personagemX = width - 180;
    // Mensagem de "Você chegou à fita!"
    fill(0);
    textSize(18);
    textAlign(CENTER, CENTER);
    text("Pressione 'V' para cortar a fita!", width / 2, height - 30);
  } else if (fitaCortada && personagemX >= width - 100) {
    // Personagem pode entrar mais na cidade depois de cortar a fita
    personagemX = width - 100;
  }

  // Atualiza e desenha os fogos de artifício
  for (let i = fogos.length - 1; i >= 0; i--) {
    fogos[i].update();
    fogos[i].display();
    if (fogos[i].isFinished()) {
      fogos.splice(i, 1); // Remove fogos que já terminaram
    }
  }
}

function keyPressed() {
  // Se a tecla 'V' for pressionada e o personagem estiver na fita
  if (key === 'v' || key === 'V') {
    if (personagemX >= width - 180 && !fitaCortada) {
      fitaCortada = true; // Corta a fita
      gerarFogosDeArtificio(); // Gera os fogos
    }
  }
}

function desenharPersonagem() {
  fill(255); // Branco
  ellipse(personagemX, height / 2, 30, 30); // Corpo (círculo)
  rect(personagemX - 10, height / 2 + 15, 20, 30); // Pernas (retângulo)
  fill(0); // Preto
  ellipse(personagemX, height / 2 - 20, 15, 15); // Cabeça
}

function desenharFita() {
  stroke(0); // Borda preta
  strokeWeight(3);
  line(width - 150, height / 2 - 50, width - 150, height / 2 + 50); // Poste esquerdo
  line(width - 100, height / 2 - 50, width - 100, height / 2 + 50); // Poste direito
  line(width - 150, height / 2, width - 100, height / 2); // Fita (horizontal)
  noStroke(); // Remove a borda para os próximos desenhos
}

function desenharElementosCenario() {
  // Cercas (melhor posicionamento)
  stroke(100, 70, 0); // Cor da cerca
  strokeWeight(2);
  for (let x = 30; x < width - 250; x += 60) { // Desenha cercas até antes da cidade
    line(x, height / 2 - 50, x, height / 2 + 50); // Poste vertical
    line(x - 15, height / 2 - 30, x + 15, height / 2 - 30); // Linha horizontal 1
    line(x - 15, height / 2 + 30, x + 15, height / 2 + 30); // Linha horizontal 2
  }
  noStroke(); // Remove a borda

  // Árvores (melhor posicionamento e desenho)
  for (let x = 80; x < width - 250; x += 150) { // Posiciona árvores em intervalos
    // Árvore na parte superior do campo
    fill(139, 69, 19); // Tronco marrom
    rect(x - 10, height / 2 - 120, 20, 70);
    fill(34, 139, 34); // Copa verde
    ellipse(x, height / 2 - 120, 60, 80);

    // Árvore na parte inferior do campo
    fill(139, 69, 19); // Tronco marrom
    rect(x - 10, height / 2 + 50, 20, 70);
    fill(34, 139, 34); // Copa verde
    ellipse(x, height / 2 + 50, 60, 80);
  }
}

function desenharCidade() {
  fill(100); // Cinza para os prédios
  rect(width - 80, height / 2 - 100, 70, 150); // Prédio 1
  rect(width - 15, height / 2 - 150, 50, 200); // Prédio 2 (mais alto)
  rect(width - 200, height / 2 - 80, 60, 130); // Prédio 3 (um pouco antes da fita)

  // Janelas (opcional, para dar mais detalhe)
  fill(255, 255, 0); // Amarelo para janelas
  rect(width - 70, height / 2 - 90, 10, 15);
  rect(width - 60, height / 2 - 70, 10, 15);
  rect(width - 5, height / 2 - 140, 10, 15);
}

// Classe para as partículas dos fogos de artifício
class Particula {
  constructor(x, y, cor) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D().mult(random(2, 5)); // Velocidade aleatória
    this.acc = createVector(0, 0.05); // Gravidade leve
    this.cor = cor;
    this.vida = 255; // Opacidade inicial
  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.vida -= 4; // Diminui a vida (opacidade) mais rápido
  }

  display() {
    noStroke();
    fill(this.cor.r, this.cor.g, this.cor.b, this.vida);
    ellipse(this.pos.x, this.pos.y, 8, 8); // Desenha a partícula
  }

  isFinished() {
    return this.vida < 0;
  }
}

// Classe para um único fogo de artifício (conjunto de partículas)
class FogoDeArtificio {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.particulas = [];
    // Gera uma cor aleatória para este fogo específico
    this.corPrincipal = color(random(255), random(255), random(255));

    // Gera 50 partículas com variações da cor principal
    for (let i = 0; i < 50; i++) {
      let r = red(this.corPrincipal) + random(-50, 50);
      let g = green(this.corPrincipal) + random(-50, 50);
      let b = blue(this.corPrincipal) + random(-50, 50);
      // Garante que os valores de cor fiquem entre 0 e 255
      r = constrain(r, 0, 255);
      g = constrain(g, 0, 255);
      b = constrain(b, 0, 255);
      this.particulas.push(new Particula(this.pos.x, this.pos.y, color(r, g, b)));
    }
  }

  update() {
    for (let i = this.particulas.length - 1; i >= 0; i--) {
      this.particulas[i].update();
      if (this.particulas[i].isFinished()) {
        this.particulas.splice(i, 1); // Remove partículas que já terminaram
      }
    }
  }

  display() {
    for (let particula of this.particulas) {
      particula.display();
    }
  }

  isFinished() {
    return this.particulas.length === 0; // Fogo termina quando não há mais partículas
  }
}

function gerarFogosDeArtificio() {
  for (let i = 0; i < 8; i++) { // Gera 8 fogos de artifício
    let x = random(width / 4, width * 3 / 4); // Posição X aleatória no céu
    let y = random(50, height / 2 - 100); // Posição Y aleatória no céu
    fogos.push(new FogoDeArtificio(x, y));
  }
}